%clear
%N = 10;  % grid resolution
%W = [];  % will store all 3x1 weight vectors

%for i = 0:N
%    for j = 0:(N - i)
%        k = N - i - j;
%        w = [i j k] / N;
%        W = [W ; w];  % each column is a 3x1 weight vector
%    end
%end

clear
payoffmat=load('input_data_for_ahp_4_1_plastics.txt');

N = 10;  % grid resolution
W = [];  % will store all 3x1 weight vectors

for i = 0:N
    for j = 0:(N - i)
        k = N - i - j;
        w = [i j k] / N;
        W = [W ; w];  % each column is a 3x1 weight vector
    end
end

WW=zeros(size(W,1),5);

for ii=1:size(W,1)
    resVec = payoffmat * W(ii,:)';
    [B, J] = sort(resVec,'descend');
    value=J(1);
    WW(ii,1:3)=W(ii,1:3)
    WW(ii,4)=value;
    WW(ii,5)=B(1);
end

WW

save WW.txt WW -ascii
save W.txt W -ascii